---
title: Projetos
date: 2026-03-10
tags: [índice, projetos]
---

# Projetos

O trabalho. Todo ele rodando simultaneamente.

> *"Estava ocupado demais fazendo outros testes."*

---

## Portfolio CS50 (Harvard)

- [[projects/cs50|Portfolio completo]] — 5 cursos, escala crescente
- [[projects/nkd|NKD]] — o sistema de 42 nós; CS50 Final

## Universidade

- [[projects/librebase|LibreBase]] — banco de dados open-source do zero
- [[projects/librebase#ai-cli|AI CLI]] — IA de terminal conectada ao próprio sistema de arquivos de P1
- Java CRUD + Jogos — BD com verificação de e-mail; segundo jogo desbloqueia após o primeiro

## O Livro

- [[alva-saga/index|A Saga Alva]] — uma página escrita; o final existe; o meio é o trabalho
- [[archive/index|O Arquivo]] — 11 gerações de documentação

---

## O Padrão

P1 não conclui projetos — P1 constrói sistemas. O curso é a restrição. O projeto ultrapassa a restrição. Toda vez.

CS50G: 1.490 linhas. CS50 Web: 12.000 linhas. CS50 Final: o próprio sistema de conhecimento de 42 nós.

---

## O Portfolio de 16 Projetos

Do META_ARCHIVE_DEFINITIVE_V5 — portfolio completo de 16 projetos documentado na Crença 10 e 11:
- Todos os cursos CS50 (5)
- Requisitos universitários (4)
- Pesquisa de segurança independente
- LibreBase
- AI CLI
- O livro (Saga Alva + corpus filosófico)
- Esta teia de conhecimento
- A cadeia de arquivos (agora em sua 11ª geração)

---

**Voltar para:** [[index|O Mapa]]
