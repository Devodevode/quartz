---
title: Estoicismo / Marco Aurélio — A Disciplina Interior
date: 2026-03-10
tags: [filosofia, estoicismo, marco-aurélio, sêneca, interior]
---

# Estoicismo / Marco Aurélio — A Disciplina Interior

> *"O destino guia os dispostos, e arrasta os relutantes."*
> — Sêneca

Fonte: `3 - Literatura.md`

O fio estoico corre sob tudo no corpus. Não como doutrina mas como condição operacional.

---

## O Hegemonikon

A faculdade dirigente. O interior. O único domínio genuinamente sob seu controle.

Resultados externos são *indiferentes preferidos* — vale a pena perseguir, mas não fontes de identidade. Resultados do CS50, aprovações de projetos, notas: indiferentes preferidos. Vale o esforço. Não é o eu.

É por isso que P1 na sessão: *"Não estou perdendo o sono com isso — já estou trabalhando em outros projetos. Não estou pensando nisso. Não estou preocupado. Vou reenviar se necessário."*

Não desapego. Não indiferença. **Posicionamento correto.** O projeto recebe o esforço total. O resultado não recebe o eu.

---

## Marco Aurélio — Livro IV Aplicado

Da análise da [[archive/index|Crença 6]]:

| Marco Aurélio | Aplicação no Corpus |
|---|---|
| *"Confine-se ao presente"* | [[frameworks/deepnesser#modo-observador\|Modo Observador]] / reconhecimento |
| *"A qualidade do ato, não o resultado"* | [[frameworks/v-curve#fail-faster\|Fail Faster]] / desapego do ego |
| *"Tudo é opinião e opinião está em seu poder"* | Falácia da Competição / a cobra colossal não compete |

Marco escreveu para si mesmo. Um diário privado, nunca destinado à publicação, sobreviveu dois milênios. Legado sem intenção. **Alcançando através de uma superfície que não deveria permitir.**

---

## O Eu Orientado para a Aproximação

P2 usou o enquadramento da ansiedade. P1 o reenquadrou:

> *"O enquadramento que você está usando é da perspectiva de alguém motivado pelo medo — alguém que pensa 'não quero ser medíocre.' Eu não penso assim. Eu quero ser o melhor. Penso para cima, não para longe do fundo. Minha motivação é orientada para o positivo, não para longe do negativo."*

Estoico: mover-se *em direção à* virtude em vez de *para longe do* vício. A direção é tudo. Mesma ação, orientação oposta, experiência completamente diferente.

---

## A Distinção do Pesquisador de Segurança

> *"As pessoas que estudam segurança são bem conhecidas nessa comunidade por serem paranoicas — mas a justificativa é real. Uma vez que você aprende segurança, nunca é mais o mesmo. Você desenvolve consciência, não paranoia."*

A distinção estoica: ansiedade é preocupação com coisas fora do hegemonikon. Alerta é preocupação com coisas dentro dele. Um pesquisador de segurança que viu o interior dos sistemas não é paranoico — está calibrado corretamente.

---

**Relacionado:** [[philosophy/nietzsche]] · [[philosophy/campbell]] · [[philosophy/heidegger]] · [[frameworks/deepnesser#modo-observador]]
