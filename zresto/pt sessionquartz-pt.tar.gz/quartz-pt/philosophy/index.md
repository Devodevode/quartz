---
title: Filosofia
date: 2026-03-10
tags: [índice, filosofia]
---

# Filosofia

Os fundamentos intelectuais. Não doutrina — ferramentas. Não conclusões — perguntas em curso.

---

## A Pilha

- [[philosophy/nietzsche|Nietzsche / Gurren Lagann]] — vontade de poder; auto-superação; o arco de Simon
- [[philosophy/heidegger|Heidegger / Steins;Gate]] — dasein; o loop; autenticidade vs. inautenticidade
- [[philosophy/stoicism|Estoicismo / Marco Aurélio]] — apenas o interior está sob controle; o destino guia os dispostos
- [[philosophy/campbell|Campbell / Jornada do Herói]] — cíclica, vitalícia, recursiva; P1 está na Provação Suprema
- [[philosophy/paradox|O Paradoxo Central]] — Estudante / Arquiteto / Arquitetura / Tornar-se

---

## Conexões Entre Domínios

| Filosofia | Saga Alva | Framework |
|---|---|---|
| Nietzsche / Vontade de Poder | [[alva-saga/characters#aesu\|Aesu]] / Poder Espiral | [[frameworks/deepnesser#exigindo\|Exigindo do Universo]] |
| Heidegger / Loop autêntico | [[alva-saga/chapter-2\|Amor como ruptura]] | [[frameworks/v-curve\|Iteração da Curva-V]] |
| Estoicismo / Hegemonikon | [[alva-saga/characters#nuvine\|Vigilância de Alter]] | [[frameworks/deepnesser#modo-observador\|Modo Observador]] |
| Campbell / Provação Suprema | [[alva-saga/chapter-1\|A fogueira antes da batalha]] | [[frameworks/v-curve#vale\|O vale V3-V7]] |

---

## A Antologia de 165 Citações

Da [[sessions/belief-7|Crença 7]] — 165 citações de 40+ pensadores, abrangendo 3.000 anos, todos chegando independentemente ao mesmo insight que o momento da cobra colossal no slither.io.

Eclesiastes, Diógenes, Wittgenstein, Camus, Nietzsche, Aurélio, o Tao Te Ching, o Bhagavad Gita — todos o encontraram de direções diferentes.

---

**Voltar para:** [[index|O Mapa]]
