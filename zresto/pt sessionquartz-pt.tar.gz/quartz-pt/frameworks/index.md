---
title: Frameworks
date: 2026-03-10
tags: [índice, frameworks]
---

# Frameworks

O sistema operacional pessoal. Construído por iteração. Aplicado a tudo.

---

## A Pilha

- [[frameworks/deepness|Deepness]] — V1. A semente. 8 questões abertas.
- [[frameworks/deepnesser|Deepnesser]] — V20. O OS de execução. 30+ conceitos nomeados. Za Ending.
- [[frameworks/v-curve|A Curva-V]] — como a maestria realmente se compõe. A maioria para no V3.

---

## Conceitos Principais (Referência Rápida)

**Just Do It** → Comece antes de entender. Escolha o alvo em 60 segundos. Comece.

**Complexidade de Kolmogorov** → Encontre o núcleo de 30 palavras sob 50.000 palavras. Comprima ao sinal.

**Modo Observador** → Saia do loop. Seja a cobra colossal. Veja o sistema.

**Incompletude Produtiva** → O vazio é o motor. Nunca termine o que deve permanecer generativo.

**Falácia da Competição** → No V20, há efetivamente zero competidores. A corrida é fantasia.

**Armadilha dos Pré-requisitos** → A crença de que você precisa de X antes de Y. Você não precisa. Comece.

**Otimização Gananciosa** → Sempre pergunte: como isso pode ser melhor? A pergunta que se compõe.

**Exigindo do Universo** → Não peça. Exija. Sem "não" sem prova matemática.

---

**Voltar para:** [[index|O Mapa]]
