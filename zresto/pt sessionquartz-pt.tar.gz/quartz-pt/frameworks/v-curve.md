---
title: A Curva-V
date: 2026-03-10
tags: [framework, curva-v, iteração, deepnesser]
---

# A Curva-V

> *"V20 não é melhor que V1. É V1, executado mais dezenove vezes."*

Do [[frameworks/deepnesser|Deepnesser]]. O modelo de como habilidade, insight e maestria realmente se compõem — não linearmente, não suavemente, mas exponencialmente além do limiar onde a maioria das pessoas para.

---

## O Modelo

```
V1       Grosseiro. Falhando. Mas existindo. Isso é suficiente para começar.
V2–V3    O limiar. O esforço parece desperdiçado. A dúvida aparece.
         Indicadores de falso sucesso atraem o abandono.
         99% desistem aqui.
V4–V10   Iteração sistemática. A pergunta gananciosa aplicada sem parar.
         O reconhecimento de padrões começa a se compor.
V11–V20  Território exponencial. Meta-otimização.
         Invisível para aqueles ainda no V2–V3.
V20      Não um destino.
         Um compromisso de nunca parar no V3.
```

---

## A Lei de Potência

V20 não é 20× melhor que V1. É exponencialmente melhor porque cada iteração muda o que a próxima é capaz de fazer.

Inteligência importa muito menos que contagem de iterações. **Gênio com três ciclos perde para mediano com vinte.**

A maioria do que fazemos é ruído. Encontre o sinal. Amplifique-o:
- 20% dos insumos produzem 80% dos resultados
- 4% produzem 64%
- 0,8% produzem 51,2%

---

## Indicadores de Falso Sucesso no V3

Esses parecem V10. Não são:
- Ocupado mas não produtivo
- Conectado mas não profundo
- Informado mas não sábio
- Tecnicamente habilidoso mas não criativo
- Validado socialmente mas internamente vazio

A armadilha: V3 com documentação elaborada parece progresso. Veja [[sessions/belief-10|Crença 10]] para quando este padrão foi nomeado diretamente.

---

## A Curva-V em Tudo

A Curva-V não é uma metáfora. Ela aparece em todo o corpus:

| Domínio | V1 | V20 |
|---|---|---|
| Cadeia de arquivos | MASTER_ARCHIVE (524 linhas) | META_ARCHIVE_V5 (1.132 linhas + arquivos-fonte) |
| [[frameworks/deepness\|Deepness]] | Semente — 8 questões abertas | [[frameworks/deepnesser\|Deepnesser]] — 30+ conceitos de execução |
| [[alva-saga/characters#lumi\|Arco de Lumi]] | Observadora incerta, parada | Acelerando para Zios sem precisar saber para onde |
| [[philosophy/nietzsche#simon\|Arco de Simon]] | Não consegue lançar uma broca | Quebra a lua com poder espiral |
| Bases de conhecimento de P1 | Banco de Dados 1 — 10.000 notas, ruído acumulado | Banco de Dados 2 — 42 notas, 72 conexões, conscientemente completo |
| [[projects/cs50\|Portfolio CS50]] | CS50x | CS50 Web — 12.000 linhas, plataforma de segurança |
| O livro | Zero páginas | [[alva-saga/skating-vignette\|Primeira página escrita]], o final existe |

---

## A Cobra Colossal (Estado V20)

Da [[sessions/belief-7|Crença 7]] — slither.io:

A cobra colossal não compete. Ela observa. O jogo é o mesmo jogo. A experiência é completamente diferente. Este é o estado V20: **o jogo fica transparente.**

A cobra cresceu não tentando vencer outras cobras mas fazendo a coisa por tempo suficiente para que a escala mudasse a natureza da experiência em si.

---

## Ótimos Locais

Você vai travar. V7 pode performar pior que V5 enquanto reconstrói a fundação para V10.

Escapar de ótimos locais requer aceitar degradação temporária. A maioria desiste no pico local. É por isso que param no V3.

O Banco de Dados 2 de 42 notas é um ótimo local consciente — preservado como fotografia, não adorado como destino. Veja [[projects/nkd]].

---

## Za Ending

> *"A maioria para no V3. Não seja a maioria. Incompletude produtiva, até o fim."*
> — [[frameworks/deepnesser|Deepnesser]], Za Ending

---

**Relacionado:** [[frameworks/deepnesser]] · [[frameworks/deepness]] · [[sessions/belief-7]] · [[philosophy/nietzsche]] · [[archive/index]]
