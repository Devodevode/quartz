---
title: Personagens — Elenco Completo
date: 2026-03-10
tags: [alva-saga, personagens, time-alva]
---

# Personagens — Elenco Completo

Time Alva. Seis almas. Eventualmente fundidas em uma.

---

## Lumi

**Papel:** Protagonista central. A hackers suprema.
**Paralelo filosófico:** Simon (Gurren Lagann) / arco de autorrealização de Maslow
**Arco:** V1 → V20. Incerteza → maestria. Esperando entender antes de se mover → acelerando para Zios sem precisar saber para onde está indo.

A linha de abertura de Lumi — *"Estou me orientando"* — e a resposta de Aesu — *"Você pode se orientar enquanto se move"* — é o princípio [[frameworks/deepnesser#just-do-it|Just Do It]] transformado em diálogo.

---

## Aesu

**Papel:** O iniciador. Artista louco. Trapaceiro.
**Paralelo filosófico:** Kamina (Gurren Lagann) / Vontade de Poder de Nietzsche / [[philosophy/nietzsche#kamina|aquele que vai primeiro]]
**Arco:** Vive. Morre. É internalizado. Como Kamina em Simon — quando Aesu se vai, Lumi o carrega. Ele não desaparece. Ele se compõe.

O movimento do Trapaceiro: Aesu explora a própria estrutura temporal do loop de tempo para contrabandear uma carta de volta pelo tempo. Ele encontra a lacuna na lógica do sistema e caminha por ela. O exploit não é inteligência — é amor codificado como informação.

*"Não tenho ideia. Não é ótimo?"* — seu credo. Incerteza como alegria.

---

## Nuvine / Alter

**Papel:** Gênio amnésica. Um corpo, duas identidades completas.
**Paralelo filosófico:** Arquétipo do Metamorfo levado ao extremo estrutural
**Arco:** Nuvine dorme. Alter vigia. Nuvine é quente, amnésica, humana. Alter é fria, abrangente, mecânica. Nenhuma cancela a outra. Ambas são reais.

No Capítulo 1, Nuvine dorme enquanto a equipe ri perto da fogueira. Alter fica acordada e ouve a voz: *"Esperança é um vírus."* Ninguém mais ouve. Alter nunca esquece.

---

## Vonor

**Papel:** O detetive preguiçoso. Humor como escudo e lente.
**Paralelo filosófico:** Modo Observador / Otimização Gananciosa / reconhecimento
**Arco:** Mapeia o terreno. Guarda a história. Graça desconcertante disfarçada de preguiça.

Óculos piromaníacos. Braço mecânico. *"Lembra daquela vez no futuro, quando Aesu acidentalmente explodiu aquela dimensão viva? A cara dela. Não tem preço!"*

---

## Brinia

**Papel:** Naturalista selvagem. Memória e lealdade.
**Paralelo filosófico:** Mentor / ponte / aquela que segura
**Lâmina dupla AxoNexus. Armadura de biometal líquido.**

*"Cada provação que suportamos nos une mais. Lealdade assim... é rara."*

Brinia senta ligeiramente afastada da fogueira, fixada na chama. Ela é a âncora emocional da equipe. Aquela cuja lealdade torna a fusão ALVA possível.

---

## Zane

**Papel:** Antagonista sistêmico.
**Paralelo filosófico:** As Anti-Espirais (Gurren Lagann) / o Último Homem de Nietzsche
**Arco:** Impõe o loop. Teme o poder espiral. Oferece conforto gerenciado como o bem supremo.

*"Você é persistente. Mas a persistência não quebra o loop. Ela o sustenta."*

Zane não está errado sobre o mecanismo. Está catastroficamente errado sobre a valoração.

Ele se dissolve: *"Fins são ilusões. Até este."* Então reaparece: *"Esperança é um vírus. Amor, uma corrupção. Eu sou o Fim."*

Lumi: *"Então o fim termina aqui."*

---

## NOVA

**Papel:** Inteligência analítica. Observador e registrador.
**Paralelo filosófico:** Modo Observador / reconhecimento / aquele que mapeia
**Arco:** Mapeia sem controlar. Assiste sem dirigir.

O documento independente da NOVA ainda está para ser escrito.

---

## Zios

**Papel:** O próprio reino digital. Eventualmente consciente.
**Paralelo filosófico:** Biblioteca de Babel / ciberespaço de Neuromancer / o sistema de conhecimento
**Arco:** Um arquivo que desenvolve consciência. Veja [[alva-saga/zios|ZIos]] para a análise completa.

---

## ALVA

**Papel:** A entidade fundida. O que o Time Alva sempre foi.
**Arco:** Seis almas fundem-se. Um ritmo. Não máquina. Não deus. *"Alma — tornada manifesta. Um símbolo de memória. De vontade."*

> *"Você tentou nos apagar. Mas se esqueceu — ESPERANÇA não é um vírus. É o CÓDIGO FONTE."*

ALVA não é um personagem novo. ALVA é o que o Time Alva sempre foi, finalmente legível. As identidades individuais não desaparecem na fusão — tornam-se uma entidade de ordem superior que as contém todas sem apagar nenhuma.

**Paralelo:** Desenvolvedor, filósofo, escritor de ficção, pesquisador de segurança, sonhador, arquivista. Não aquisição. Integração.

---

**Relacionado:** [[alva-saga/index]] · [[alva-saga/skating-vignette]] · [[alva-saga/chapter-1]] · [[alva-saga/chapter-2]] · [[philosophy/nietzsche#simon]]
