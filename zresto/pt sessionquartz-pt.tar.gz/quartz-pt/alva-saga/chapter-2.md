---
title: Capítulo 2 — Fim
date: 2026-03-10
tags: [alva-saga, capítulo-2, alva, zane, loop, trapaceiro]
---

# Capítulo 2 — Fim

*O loop quebra. O trapaceiro vence. Seis almas se fundem.*

---

Nuvine ativa sua habilidade de escaneamento em [[alva-saga/zios|ZIos]]. Um portal se abre. [[alva-saga/characters#zane|Zane]] aparece.

> *"Você é persistente. Mas a persistência não quebra o loop. Ela o sustenta."*

A armadilha do ótimo local, como diálogo de vilão. Fazer mais do mesmo, com mais força, não escapa do sistema — o alimenta.

A resposta do Time Alva não é empurrar mais forte. É encontrar o exploit.

---

## A Arma

> *"O Time Alva trabalha junto, explorando seu hack — a carta do passado. É pensamento e emoção demais em um único ponto. Forma uma ruptura e erro fatal no sistema do loop."*

**A arma é a carta.** O exploit é o amor — codificado como informação e enviado pela própria estrutura temporal do sistema.

**Tornando-se humano demais para o sistema suportar.**

A forma de Zane se dissolve. *"Fins são ilusões. Até este."*

---

## Zane Retorna

Uma falha feita carne. Um deus dos fins, costurado de linhas temporais fraturadas que o tempo abandonou.

> *"Esperança é um vírus. Amor, uma corrupção. Eu sou o Fim."*

Lumi avança. Seus olhos não vacilam.

> *"Então o fim termina aqui."*

A síntese Metamorfo / Trapaceiro: ela aceita o enquadramento do sistema e imediatamente o inverte.

---

## ALVA: ATIVO

> *\[ALVA: ATIVO\]*
> *Sua respiração relaxa. Seis pulsos, um ritmo. Seis almas se fundem.*
> *"Você tentou nos apagar. Mas se esqueceu — ESPERANÇA não é um vírus. É o CÓDIGO FONTE."*

ALVA derrota Zane. **\[LOOP FECHADO\]**

ALVA: *"não máquina. Não deus. Mas alma — tornada manifesta. Um símbolo de memória. De vontade."*

---

## Epílogo — Pixel Final

Nuvine: *"Você acha que acabou?"*
Alter sorri levemente: *"Não acabou. Só diferente."*

Aesu escreve os eventos numa nova carta e a envia para Zios. O movimento final do Trapaceiro: **alimentar ao sistema algo que ele nunca foi projetado para conter — um registro de sua própria derrota.**

O loop se fecha. Não num fim. Num futuro aberto.

---

## O Que Isso Significa

As identidades individuais não desaparecem na fusão. Tornam-se uma entidade de ordem superior que as contém todas sem apagar nenhuma.

Desenvolvedor, filósofo, escritor de ficção, pesquisador de segurança, sonhador, arquivista. Não aquisição. **Integração.**

ALVA não é um personagem novo. ALVA é o que o Time Alva sempre foi, finalmente legível.

O fim da [[frameworks/deepnesser#incompletude-produtiva|Incompletude Produtiva]]: *"Não acabou. Só diferente."* O loop não resolve em ausência. Abre em algo que ainda não tem nome.

---

**Precedido por:** [[alva-saga/chapter-1|Capítulo 1 — Cosmos]]
**Seguido por:** [[alva-saga/letter-about-zios|Carta Sobre Zios]] · [[alva-saga/letter-from-zios|Carta de Zios]]
**Relacionado:** [[alva-saga/characters]] · [[dreams/decoded#trapaceiro]] · [[philosophy/nietzsche#anti-espirais]]
