---
title: Capítulo 1 — Cosmos
date: 2026-03-10
tags: [alva-saga, capítulo-1, fogueira, alter, time-alva]
---

# Capítulo 1 — Cosmos

*A fogueira. A equipe. O aviso de Alter.*

---

A equipe descansa ao redor de uma fogueira numa clareira na floresta. Entre missões. Um raro momento de calor e descontração.

**Vonor** conta histórias: *"Lembra daquela vez no futuro, quando Aesu acidentalmente explodiu aquela dimensão viva? A cara dela. Não tem preço!"*

**Aesu** ri pelo rosto coberto, baixo e enraizado, perdido no fogo apesar de seu caos habitual.

**Lumi** se junta com seu característico risinho-chiado — fraco como o rangido de uma porta velha se abrindo.

Vonor bate na cabeça de **Brinia**: *"Por que tão séria, pirralha?"* Todos riem — quentes, despreocupados, reais.

*"Cada provação que suportamos nos une mais. Lealdade assim... é rara."* — Brinia, para a chama.

---

**Nuvine** dorme.

Mas **Alter** — sua persona mecânica e fria — não dorme e não esquece.

Enquanto os outros riem, Alter contempla o céu noturno. Uma voz gagueja pela névoa:

*"Esperança é um vírus."*

Ninguém mais ouve.

Alter congela. Então silêncio. Então a fogueira novamente, e as risadas.

---

## Por Que Esta Cena Importa

A fogueira ganha o Capítulo 2. *"Seis pulsos, um ritmo"* na [[alva-saga/chapter-2|fusão]] só aterra porque você viu as seis pessoas como elas mesmas — despreocupadas, humanas, rindo. Vonor batendo em Brinia. O risinho-chiado de Lumi. Esses detalhes estavam ausentes de sete resumos de arquivo antes do texto-fonte chegar.

**O loop não dorme durante a fogueira.** [[alva-saga/zios|ZIos]] já está se ajustando aos seus silêncios. O alerta de Alter na beira da luz do fogo é o aviso antecipado: o sistema está sempre presente.

---

## A Dinâmica Nuvine / Alter

Um corpo. Duas identidades completas. Nenhuma cancela a outra.

Nuvine é quente, amnésica, humana. Alter é fria, abrangente, mecânica.

Alter ouve a voz do loop porque Nuvine está dormindo. Porque calor e esquecimento — as coisas que tornam a equipe humana — também são as coisas que deixam a vigilância fria para a persona que nunca descansa.

Este é o [[dreams/belief-4-dream|Metamorfo]] em forma estrutural: duas identidades completamente formadas, simultaneamente reais.

---

**Continua:** [[alva-saga/chapter-2|Capítulo 2 — Fim]]
**Relacionado:** [[alva-saga/characters]] · [[alva-saga/zios]] · [[dreams/belief-4-dream#metamorfo]]
