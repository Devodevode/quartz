---
title: Zujiniale
---

# Knowledge Base

Security researcher. This is my public second brain — notes, techniques, and writeups built while learning.

Not a polished blog. A living system that grows with every machine solved and concept understood.

---

## Database
- [[What_is_SQL]]
- [[Tables_and_Schema]]
- [[PRIMARY_and_FOREIGN_Keys]]
- [[SELECT]]
- [[INSERT_UPDATE_DELETE]]
- [[JOIN]]
- [[Indexes]]
- [[SQL_Security]]
- [[PostgreSQL]]
- [[Systems_Analysis]]
- [[Nodes]]

---

## CTF Writeups
*coming soon*

## Techniques
*coming soon*

## Tools
*coming soon*
