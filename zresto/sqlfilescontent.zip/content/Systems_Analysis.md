---
title: Systems Analysis
tags: [database, design]
---

# Systems Analysis

The process of examining a system to understand its components, relationships, and how to model them in a database.

## Key steps
1. **Identify entities** — what are the "things" in the system? (users, products, orders)
2. **Identify attributes** — what describes each entity?
3. **Identify relationships** — how do entities relate to each other?

## Entity-Relationship (ER) concepts

### Cardinality
| Type | Example |
|---|---|
| One-to-One | User → Profile |
| One-to-Many | User → Orders |
| Many-to-Many | Students ↔ Courses |

### Many-to-Many requires a junction table
```sql
CREATE TABLE student_courses (
  student_id INT REFERENCES students(id),
  course_id  INT REFERENCES courses(id),
  PRIMARY KEY (student_id, course_id)
);
```

## Normalization
Organizing data to reduce redundancy.

| Form | Rule |
|---|---|
| 1NF | No repeating groups, atomic values |
| 2NF | No partial dependencies |
| 3NF | No transitive dependencies |

## Related
- [[Tables_and_Schema]]
- [[PRIMARY_and_FOREIGN_Keys]]
- [[PostgreSQL]]
