---
title: JOIN
tags: [database, queries]
---

# JOIN

Combines rows from two or more tables based on a related column.

## Types

### INNER JOIN
Returns only rows with matches in **both** tables.
```sql
SELECT users.username, orders.total
FROM users
INNER JOIN orders ON users.id = orders.user_id;
```

### LEFT JOIN
Returns all rows from the **left** table, matched rows from the right (NULL if no match).
```sql
SELECT users.username, orders.total
FROM users
LEFT JOIN orders ON users.id = orders.user_id;
```

### RIGHT JOIN
Opposite of LEFT JOIN.

### FULL OUTER JOIN
Returns all rows from both tables.

## Visual reference
```
INNER  →  only overlap
LEFT   →  all left + overlap
RIGHT  →  all right + overlap
FULL   →  everything
```

## Related
- [[SELECT]]
- [[PRIMARY_and_FOREIGN_Keys]]
