---
title: PostgreSQL
tags: [database, tools]
---

# PostgreSQL

Open-source, production-grade relational database. One of the most powerful free databases available.

## Connect
```bash
psql -U username -d database_name
psql -h localhost -U postgres
```

## Useful psql commands
| Command | Action |
|---|---|
| `\l` | List databases |
| `\c dbname` | Connect to database |
| `\dt` | List tables |
| `\d tablename` | Describe table |
| `\q` | Quit |

## Create a database
```sql
CREATE DATABASE mydb;
```

## Common PostgreSQL-specific features
- **SERIAL** / **BIGSERIAL** — auto-increment IDs
- **JSONB** — store and query JSON data
- **Array types** — store arrays in columns
- **Full-text search** — built-in

```sql
CREATE TABLE posts (
  id      SERIAL PRIMARY KEY,
  title   VARCHAR(200),
  body    TEXT,
  meta    JSONB
);
```

## Related
- [[What_is_SQL]]
- [[Indexes]]
- [[SQL_Security]]
