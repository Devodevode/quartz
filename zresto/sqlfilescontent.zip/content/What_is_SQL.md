---
title: What is SQL
tags: [database, fundamentals]
---

# What is SQL

**SQL** (Structured Query Language) is the standard language for interacting with relational databases.

## Purpose
- Create and manage databases
- Query and manipulate data
- Control access and permissions

## How it works
Data is stored in **tables** (rows and columns), and SQL lets you interact with that data using commands grouped into categories:

| Category | Purpose | Examples |
|---|---|---|
| DDL | Define structure | CREATE, ALTER, DROP |
| DML | Manipulate data | SELECT, INSERT, UPDATE, DELETE |
| DCL | Control access | GRANT, REVOKE |

## Key concept
SQL is **declarative** — you describe *what* you want, not *how* to get it. The database engine figures out the rest.

## Related
- [[Tables_and_Schema]]
- [[SELECT]]
- [[PostgreSQL]]
