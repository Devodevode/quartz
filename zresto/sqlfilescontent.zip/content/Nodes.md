---
title: Nodes
tags: [database, graph]
---

# Nodes

In graph databases, a **node** represents an entity (like a row in SQL). Nodes connect to each other via **edges** (relationships).

## Graph vs Relational
| Concept | Relational | Graph |
|---|---|---|
| Entity | Row | Node |
| Relationship | Foreign key / JOIN | Edge |
| Query language | SQL | Cypher (Neo4j) |

## When to use a graph database
- Highly connected data (social networks, recommendation engines)
- Relationship traversal is the main query pattern
- Data structure changes frequently

## Example (Neo4j Cypher)
```cypher
-- Create nodes
CREATE (a:Person {name: 'Alice'})
CREATE (b:Person {name: 'Bob'})

-- Create relationship
MATCH (a:Person {name: 'Alice'}), (b:Person {name: 'Bob'})
CREATE (a)-[:KNOWS]->(b)

-- Query
MATCH (a:Person)-[:KNOWS]->(b:Person)
RETURN a.name, b.name
```

## SQL equivalent for graphs
You can model graph-like structures in SQL using self-referencing tables:

```sql
CREATE TABLE relationships (
  from_id INT REFERENCES users(id),
  to_id   INT REFERENCES users(id),
  type    VARCHAR(50)
);
```

## Related
- [[Systems_Analysis]]
- [[PRIMARY_and_FOREIGN_Keys]]
- [[What_is_SQL]]
