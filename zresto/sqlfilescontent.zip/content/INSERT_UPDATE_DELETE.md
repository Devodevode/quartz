---
title: INSERT, UPDATE, DELETE
tags: [database, queries]
---

# INSERT, UPDATE, DELETE

The three data modification commands (DML).

## INSERT
Adds new rows.

```sql
INSERT INTO users (username, email)
VALUES ('bidi', 'bidi@example.com');

-- Multiple rows
INSERT INTO users (username, email) VALUES
  ('alice', 'alice@example.com'),
  ('bob',   'bob@example.com');
```

## UPDATE
Modifies existing rows.

```sql
UPDATE users
SET email = 'new@example.com'
WHERE username = 'bidi';
```

> ⚠️ Always use WHERE — without it, every row gets updated.

## DELETE
Removes rows.

```sql
DELETE FROM users
WHERE username = 'bidi';
```

> ⚠️ Always use WHERE — without it, every row gets deleted.

## TRUNCATE
Faster than DELETE for clearing an entire table.

```sql
TRUNCATE TABLE logs;
```

## Related
- [[SELECT]]
- [[Tables_and_Schema]]
