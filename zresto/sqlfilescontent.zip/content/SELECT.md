---
title: SELECT
tags: [database, queries]
---

# SELECT

The most used SQL command. Retrieves data from one or more tables.

## Syntax
```sql
SELECT column1, column2
FROM table
WHERE condition
ORDER BY column
LIMIT n;
```

## Examples

```sql
-- All columns
SELECT * FROM users;

-- Specific columns
SELECT username, email FROM users;

-- With filter
SELECT * FROM users WHERE created > '2024-01-01';

-- Sorted
SELECT * FROM users ORDER BY username ASC;

-- Limited
SELECT * FROM users LIMIT 10;
```

## Aliases
```sql
SELECT username AS name, email AS contact
FROM users;
```

## Aggregate functions
```sql
SELECT COUNT(*)       FROM users;
SELECT AVG(salary)    FROM employees;
SELECT MAX(created)   FROM users;
```

## Related
- [[JOIN]]
- [[INSERT_UPDATE_DELETE]]
- [[Indexes]]
