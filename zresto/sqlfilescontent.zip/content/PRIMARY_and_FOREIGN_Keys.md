---
title: PRIMARY and FOREIGN Keys
tags: [database, fundamentals]
---

# PRIMARY and FOREIGN Keys

## Primary Key
Uniquely identifies each row in a table. Must be **unique** and **not null**.

```sql
CREATE TABLE users (
  id       INT PRIMARY KEY,
  username VARCHAR(50)
);
```

## Foreign Key
Links a column in one table to the primary key of another. Enforces **referential integrity**.

```sql
CREATE TABLE orders (
  id      INT PRIMARY KEY,
  user_id INT REFERENCES users(id),
  total   DECIMAL
);
```

## Referential Integrity
If `user_id` in `orders` must match an existing `id` in `users` — you can't create an order for a user that doesn't exist.

## ON DELETE behavior
| Option | Effect |
|---|---|
| CASCADE | Delete child rows automatically |
| SET NULL | Set foreign key to NULL |
| RESTRICT | Block the delete |

## Related
- [[Tables_and_Schema]]
- [[Systems_Analysis]]
