---
title: SQL Security
tags: [database, security]
---

# SQL Security

## SQL Injection
The most common database attack. Malicious SQL is inserted into input fields.

### Vulnerable example
```python
query = "SELECT * FROM users WHERE username = '" + input + "'"
# input: ' OR '1'='1
# result: SELECT * FROM users WHERE username = '' OR '1'='1'
# → returns all users
```

### Fix: Parameterized queries
```python
query = "SELECT * FROM users WHERE username = %s"
cursor.execute(query, (input,))
```

## Principle of Least Privilege
Users and apps should only have the permissions they need.

```sql
-- Create a read-only user
CREATE USER readonly WITH PASSWORD 'pass';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly;
```

## Common DCL commands
```sql
GRANT  SELECT, INSERT ON users TO app_user;
REVOKE DELETE         ON users FROM app_user;
```

## Passwords
- Never store plaintext passwords
- Use hashing: bcrypt, argon2
- SQL itself doesn't hash — your application layer does

## Related
- [[PostgreSQL]]
- [[SELECT]]
- [[INSERT_UPDATE_DELETE]]
