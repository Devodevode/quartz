---
title: Indexes
tags: [database, performance]
---

# Indexes

An index speeds up data retrieval by letting the database find rows without scanning the entire table.

## Analogy
Like a book's index — instead of reading every page, you jump directly to what you need.

## Create an index
```sql
CREATE INDEX idx_username ON users(username);
```

## Primary keys are automatically indexed.

## When to use
- Columns used frequently in WHERE clauses
- Columns used in JOIN conditions
- Columns used in ORDER BY

## When NOT to use
- Small tables (full scan is faster)
- Columns that change very frequently (index must update too)

## Trade-off
Indexes **speed up reads** but **slow down writes** (INSERT, UPDATE, DELETE must update the index).

## Types (PostgreSQL)
| Type | Use |
|---|---|
| B-tree | Default, good for most cases |
| Hash | Equality checks only |
| GIN | Full-text search, arrays |
| GiST | Geometric, range queries |

## Related
- [[SELECT]]
- [[PostgreSQL]]
