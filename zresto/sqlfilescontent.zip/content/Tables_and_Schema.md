---
title: Tables and Schema
tags: [database, fundamentals]
---

# Tables and Schema

## Table
A table is a collection of related data organized into **rows** (records) and **columns** (fields).

```sql
CREATE TABLE users (
  id        INT PRIMARY KEY,
  username  VARCHAR(50),
  email     VARCHAR(100),
  created   DATE
);
```

## Schema
A schema is a **namespace** that groups related tables, views, and objects together.

```sql
-- Create a schema
CREATE SCHEMA finance;

-- Table inside a schema
CREATE TABLE finance.transactions (
  id     INT,
  amount DECIMAL
);
```

## Data Types (common)
| Type | Use |
|---|---|
| INT | Whole numbers |
| VARCHAR(n) | Variable-length text |
| TEXT | Long text |
| BOOLEAN | True/False |
| DATE | Date only |
| TIMESTAMP | Date + time |
| DECIMAL | Precise numbers |

## Related
- [[What_is_SQL]]
- [[PRIMARY_and_FOREIGN_Keys]]
- [[Indexes]]
