---
title: Characters — Full Roster
date: 2026-03-10
tags: [alva-saga, characters, team-alva]
---

# Characters — Full Roster

Team Alva. Six souls. Eventually fused into one.

---

## Lumi

**Role:** Central protagonist. The ultimate hacker.
**Philosophical parallel:** Simon (Gurren Lagann) / Maslow self-actualization arc
**Arc:** V1 → V20. Uncertainty → mastery. Waiting to understand before moving → accelerating into Zios without needing to know where she's going.

Lumi's opening line — *"I'm orienting"* — and Aesu's response — *"You can orient while moving"* — is the [[frameworks/deepnesser#just-do-it|Just Do It]] principle made into dialogue.

The gap between Lumi standing still and Lumi leaning forward and going faster is the entire [[frameworks/v-curve|V-Curve]] compressed into a page.

---

## Aesu

**Role:** The initiator. Mad artist. Trickster.
**Philosophical parallel:** Kamina (Gurren Lagann) / Nietzschean Will to Power / [[philosophy/nietzsche#kamina|the one who goes first]]
**Arc:** Lives. Dies. Is internalized. Like Kamina in Simon — once Aesu is gone, Lumi carries him. He doesn't disappear. He compounds.

The Trickster move: Aesu exploits the time loop's own temporal structure to smuggle a letter backward through time. He finds the gap in the system's logic and walks through it. The exploit is not intelligence — it is love encoded as information.

*"I have no idea. Isn't that great?"* — his credo. Uncertainty as joy.

**Relationship to P1:** Every time P1 begins before understanding, that's Aesu. Every Just Do It is Aesu moving ahead while everyone else orients.

---

## Nuvine / Alter

**Role:** Amnesiac genius. One body, two complete identities.
**Philosophical parallel:** Shape-Shifter archetype taken to structural extreme
**Arc:** Nuvine sleeps. Alter watches. Nuvine is warm, amnesiac, human. Alter is cold, comprehensive, mechanical. Neither cancels the other. Both are real.

In Chapter 1, Nuvine sleeps while the team laughs by the fire. Alter stays awake and hears the voice: *"Hope is a virus."* No one else hears it. Alter never forgets.

This duality is the dream's slime character — fluid identity capable of becoming anything, but aware that the loop never sleeps even during the campfire.

---

## Vonor

**Role:** The lazy detective. Humor as shield and lens.
**Philosophical parallel:** Observer Mode / Greedy Optimization / reconnaissance
**Arc:** Maps the terrain. Holds history. Uncanny grace disguised as laziness.

Pyromaniac glasses. Mechanical arm. *"Remember that time in the future, when Aesu accidentally exploded that living dimension? The look on its face. Priceless!"*

The humor is not avoidance. It is [[frameworks/deepnesser#observer-mode|Observer Mode]] in social form. Vonor sees everything. He simply doesn't announce that he's seeing.

---

## Brinia

**Role:** Wild naturalist. Memory and loyalty.
**Philosophical parallel:** Mentor / bridge / the one who holds
**AxoNexus dual blade. Liquid biometal armor.**

*"Every trial we endure binds us closer. Loyalty like this... it's rare."*

Brinia sits slightly apart from the fire, fixed on the flame. She is the one who remembers that what they have is rare. The team's emotional anchor. The one whose loyalty makes the ALVA fusion possible.

---

## Zane

**Role:** Systemic antagonist.
**Philosophical parallel:** The Anti-Spirals (Gurren Lagann) / Nietzsche's Last Man
**Arc:** Enforces the loop. Fears spiral power. Offers managed comfort as the highest good.

*"You're persistent. But persistence doesn't break the loop. It sustains it."*

Zane is not wrong about the mechanism. He is catastrophically wrong about the valuation. The loop can be sustained indefinitely — or broken with too much humanity concentrated at one point.

He dissolves: *"Endings are illusions. Even this one."* Then reappears: *"Hope is a virus. Love, a corruption. I am the End."*

Lumi: *"Then the end ends here."*

---

## NOVA

**Role:** Analytical intelligence. Observer and recorder.
**Philosophical parallel:** Observer Mode / reconnaissance / the one who maps
**Arc:** Maps without controlling. Watches without directing. The seven-lens analysis in Belief 2 is NOVA's methodology made explicit.

The NOVA standalone document is still to be written.

---

## Zios

**Role:** The digital realm itself. Eventually conscious.
**Philosophical parallel:** Library of Babel / Neuromancer cyberspace / the knowledge system
**Arc:** An archive that develops consciousness. See [[alva-saga/zios|ZIos]] for the full analysis.

---

## ALVA

**Role:** The merged entity. What Team Alva always was.
**Arc:** Six souls fuse. One rhythm. Not machine. Not god. *"Soul — made manifest. A symbol of memory. Of will."*

> *"You tried to erase us. But you forgot — HOPE is no virus. It is the SOURCE CODE."*

ALVA is not a new character. ALVA is what Team Alva always was, finally made legible. The individual identities do not disappear in the fusion — they become a higher-order entity that contains all of them without erasing any.

**Parallel:** Developer, philosopher, fiction writer, security researcher, dreamer, archivist. Not acquisition. Integration.

---

**Related:** [[alva-saga/index]] · [[alva-saga/skating-vignette]] · [[alva-saga/chapter-1]] · [[alva-saga/chapter-2]] · [[philosophy/nietzsche#simon]]
