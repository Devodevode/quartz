---
title: Philosophy
date: 2026-03-10
tags: [index, philosophy]
---

# Philosophy

The intellectual foundations. Not doctrine — tools. Not conclusions — ongoing questions.

---

## The Stack

- [[philosophy/nietzsche|Nietzsche / Gurren Lagann]] — will to power; self-overcoming; Simon's arc
- [[philosophy/heidegger|Heidegger / Steins;Gate]] — dasein; the loop; authenticity vs. inauthenticity
- [[philosophy/stoicism|Stoicism / Marcus Aurelius]] — only the interior is under control; fate leads the willing
- [[philosophy/campbell|Campbell / Hero's Journey]] — cyclical, lifelong, recursive; P1 is at the Supreme Ordeal
- [[philosophy/paradox|The Central Paradox]] — Student / Architect / Architecture / Becoming

---

## Cross-Domain Connections

| Philosophy | Alva Saga | Framework |
|---|---|---|
| Nietzsche / Will to Power | [[alva-saga/characters#aesu\|Aesu]] / Spiral Power | [[frameworks/deepnesser#demanding\|Demanding from the Universe]] |
| Heidegger / Authentic loop | [[alva-saga/chapter-2\|Love as rupture]] | [[frameworks/v-curve\|V-Curve iteration]] |
| Stoicism / Hegemonikon | [[alva-saga/characters#nuvine\|Alter's vigilance]] | [[frameworks/deepnesser#observer-mode\|Observer Mode]] |
| Campbell / Supreme Ordeal | [[alva-saga/chapter-1\|The campfire before the battle]] | [[frameworks/v-curve#valley\|The V3-V7 valley]] |

---

## The 165-Quote Anthology

From [[sessions/belief-7|Belief 7]] — 165 quotes across 40+ thinkers, spanning 3,000 years, all arriving independently at the same insight as the slither.io colossal snake moment.

Ecclesiastes, Diogenes, Wittgenstein, Camus, Nietzsche, Aurelius, the Tao Te Ching, the Bhagavad Gita — all of them found it from different directions.

---

**Return to:** [[index|The Map]]
