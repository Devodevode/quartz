---
title: Frameworks
date: 2026-03-10
tags: [index, frameworks]
---

# Frameworks

The personal operating system. Built through iteration. Applied to everything.

---

## The Stack

- [[frameworks/deepness|Deepness]] — V1. The seed. 8 open questions.
- [[frameworks/deepnesser|Deepnesser]] — V20. The execution OS. 30+ named concepts. Za Ending.
- [[frameworks/v-curve|The V-Curve]] — how mastery actually compounds. Most stop at V3.

---

## Core Concepts (Quick Reference)

**Just Do It** → Begin before understanding. Pick target in 60 seconds. Start.

**Kolmogorov Complexity** → Find the 30-word core beneath 50,000 words. Compress to signal.

**Observer Mode** → Step outside the loop. Be the colossal snake. See the system.

**Productive Incompleteness** → The void is the engine. Never finish what should stay generative.

**Competition Fallacy** → At V20, there are effectively zero competitors. The race is fantasy.

**Prerequisites Trap** → The belief that you need X before Y. You don't. Start.

**Greedy Optimization** → Always ask: how can this be better? The compounding question.

**Demanding from the Universe** → Do not ask. Demand. No "no" without mathematical proof.

---

**Return to:** [[index|The Map]]
