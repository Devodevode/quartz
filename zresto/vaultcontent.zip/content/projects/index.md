---
title: Projects
date: 2026-03-10
tags: [index, projects]
---

# Projects

The work. All of it running simultaneously.

> *"I was too busy making other tests."*

---

## CS50 Portfolio (Harvard)

- [[projects/cs50|Full portfolio]] — 5 courses, escalating scale
- [[projects/nkd|NKD]] — the 42-node system; CS50 Final

## University

- [[projects/librebase|LibreBase]] — open-source database from scratch
- [[projects/librebase#ai-cli|AI CLI]] — terminal AI connected to P1's own file system
- Java CRUD + Games — DB with email verification; second game unlocks after first

## The Book

- [[alva-saga/index|The Alva Saga]] — one page written; ending exists; middle is the work
- [[archive/index|The Archive]] — 11 generations of documentation

---

## The Pattern

P1 does not complete projects — P1 builds systems. The course is the constraint. The project exceeds the constraint. Every time.

CS50G: 1,490 lines. CS50 Web: 12,000 lines. CS50 Final: the 42-node knowledge system itself.

---

## The 16-Project Portfolio

From META_ARCHIVE_DEFINITIVE_V5 — full 16-project portfolio documented across Belief 10 and 11:
- All CS50 courses (5)
- University requirements (4)
- Independent security research
- LibreBase
- AI CLI
- The book (Alva Saga + philosophical corpus)
- This knowledge web
- The archive chain (now in its 11th generation)

---

**Return to:** [[index|The Map]]
