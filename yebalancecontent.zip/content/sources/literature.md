---
title: "Source · 3 — Literature (Hero's Journey)"
tags: [source]
---

# Source · 3 — Literature (Hero's Journey)

> ⚠️ **This is the original source document — verbatim, unmodified.**
> Synthesis and cross-links live in [[frameworks/literature|literature (framework)]].

---

3 - Literature
# The Hero's Journey: A Framework for Personal Transformation

> "Life has no meaning. Each of us has meaning and we bring it to life. It is a waste to be asking the question when you are the answer."  
> — Joseph Campbell

---

Joseph Campbell was influenced by Carl Jung's analytical psychology, and his extensive work in comparative mythology and religion covers many aspects of the human experience. In his best-known work, _The Hero with a Thousand Faces_, published in 1949, Campbell describes the archetypal hero's journey, or monomyth, shared by the world—the hero being one who serves and sacrifices. He writes:

> "A hero ventures forth from the world of common day into a region of supernatural wonder: fabulous forces are there encountered and a decisive victory is won: the hero comes back from this mysterious adventure with the power to bestow boons on his fellow man."

## The Hero's Journey and the Human Condition

The Hero's Journey is not just a mythological story but is deeply embedded within the human condition. It tells the story of a person encountering a difficult life problem and their journey in resolving it through personal transformation.

Sometimes the change is **intentional** (new relationships, marriage, a new job, etc.), and the Hero is motivated to attempt and endure the process of change. Other times, the change is **unintentional** (trauma, injury, relationships breaking apart, etc.), leaving the Hero shocked.

The hero journey provides a template for all change, intentional and unintentional.

### Clinical Applications

Patients who were introduced to the Hero's Journey as a means of reconceptualizing their disorder as a hero quest, rather than an external stressful task, shifted their attitude from passive to active, supporting them to become the "author of their own lives." This has been clinically tested in a diverse range of issues, such as anxiety, depression, trauma, addiction, PTSD, and psychosis.

The role of the therapist is to guide and support personal change, acting as a mentor. It allows clients to become client-heroes, assisting them to recognize where they are in their own process of change, how to navigate their own treatment journey, and author their own change story.

## The Role of Mentors

In many of the hero myths, the weakness of the hero is balanced by the appearance of strong "tutelary" figures. A central hero of Greek mythology is Achilles, the greatest of all the Greek warriors. As a boy, he was guided by the wise centaur Chiron, tutor of gods and heroes, who instructed him in the arts of medicine, music, riding, and hunting.

> "These godlike figures are in fact symbolic representatives of the whole psyche, the larger and more comprehensive identity that supplies the strength that the personal ego lacks. Their special role suggests that the essential function of the heroic myth is the development of the individual's ego-consciousness—his awareness of his own strengths and weaknesses—in a manner that will equip him for the arduous tasks with which life confronts him."

## The Necessity of Change

The significant life problem is a situation where the Hero's existing knowledge and skills are no longer efficacious. In finding a solution, the Hero is required to leave his familiar, known world and venture into the unknown.

Significant life problems force us to change. However, many of us are reluctant to do so as we do not want to sacrifice our comfort. Ignoring these matters forms unconscious snags which give us a state of impoverishment in our personality and inhibit the growth of the good qualities that lie dormant in our psyche, making our shadow blacker and denser.

We lose control of our life and become puppets of existence. As Stoic philosopher Seneca writes:

> "Fate leads the willing, and drags along the reluctant."

It is as if one keeps living but is dragged by chains or swimming against the river currents. This is a characteristic attitude of the neurotic: an artificial barrier invented by oneself which causes one to suffer from internal conflict in order to avoid facing difficult life choices.

Campbell tells us that heroic myths provide the individual with "inspiration for aspiration." Myths have the ability to link the everyday to the eternal, to give meaning to the mundane.

## The Twelve Stages of the Hero's Journey

In _The Hero with a Thousand Faces_, Campbell identified that a Hero's Journey occurs in three sequential phases: separation, initiation, and the return. These are further divided into 17 substages. However, we will be using the more popular and modern adaptation by Christopher Vogler, detailed in his work _The Writer's Journey_, which is inspired by Campbell. He proposes a Twelve Stage Hero's Journey.

---

### Phase One: Separation

#### Stage 1: The Ordinary World

The very first stage of the Hero's Journey is the **Ordinary World**, referring to one's familiar life: daily routine, the stresses and joys of work, family, and social connections. A common characteristic is a growing awareness that something is not quite right, life is somehow lacking.

For instance, an employee may be aware that the enjoyment of his work has been diminishing for some time, but the demands of their day-to-day or concerns about finding an alternative job lead them to an increasingly stressful situation, and so they cling to their Ordinary World.

#### Stage 2: The Call to Adventure

The separation phase of the Hero's Journey begins with the second stage, the **Call to Adventure**, disrupting the comfort of the Hero's Ordinary World and presenting him with a quest that must be undertaken.

Unintentional calls may include the discovery of an infidelity, the death of a loved one, the diagnosis of an illness, etc., while intentional calls include seeking a new career, moving cities, the arrival of a first child, etc.

The Call to Adventure separates the person from the aspects of their previous life and causes anxiety.

#### Stage 3: Refusal of the Call

Many are overwhelmed and believe that their problem is beyond their capabilities, leading to the third stage: **Refusal**. This is a very common and important stage that communicates the risks involved in the Journey ahead.

However, remaining in the Refusal stage will lead to a deterioration in one's life and relationships. One finds himself with little or no motivation, highlighting the ineffectiveness of one's coping strategies. This unfamiliar situation causes stress as one is unable to deal with the life problem.

#### Stage 4: Meeting the Mentor

At this crucial turning point, the Hero desperately needs guidance, leading to the fourth stage: **Meeting the Mentor**.

The Mentor is the archetypal wise old man. It is his role to assist the Hero's progress to the realization that personal change is a necessity for the resolution of his problem, giving him practical training, wise advice, or self-confidence in order to overcome the initial fears, allowing him to move from inaction to action.

These tutelary figures do not necessarily have to be physical ones—they can also be your favorite philosopher, public figure, family member, or any other person you look up to as your ideal-self.

---

### Phase Two: Initiation

#### Stage 5: Crossing the First Threshold

When the Hero is committed to change, we enter the second phase of the Hero's Journey: **Initiation**, and the fifth stage: **Crossing the First Threshold**.

The Hero now leaves the safe haven of the "Ordinary World" and enters the "Special World," an unfamiliar place where one confronts his "dragon"—his worst fear, event, person, situation, or memory long avoided. As trials become more difficult, the Hero hones his skills and gains experience. However, as the trials increase in complexity, the demands placed on the Hero lead to higher levels of anxiety, and his first confrontation with the dragon is likely to fail. Without help, he may consider giving up.

#### Stage 6: Tests, Allies, and Enemies

In the sixth stage, **Tests, Allies, and Enemies**, the Hero explores the Special World and encounters tests and enemies. Here he must seek Allies—friendly forces who support change attempts and decrease the Hero's isolation.

A common barrier here is the fear of asking for help, for being seen as less than capable, or for possibly being rejected. Ironically, vulnerability becomes a key skill in resiliency, rather than a sign of weakness.

#### Stage 7: Approach to the Inmost Cave

Stage seven is the **Approach to the Inmost Cave**, where one must make his final preparations before descending into the unknown.

#### Stage 8: The Supreme Ordeal

When the Hero is ready, he faces the eighth stage: **The Supreme Ordeal**. It is the greatest challenge yet, the moment when all looks lost for the Hero. Many feel like they are "back at square one." Fortunately, Allies have witnessed this major setback and are present to assist the Hero.

Over a period of time, the repeated confrontation with the dragon leads to the growing realization that what was once believed to be impossible is now possible. After facing the unknown and defeating the dragon, the Hero experiences a psychological death and rebirth—the death of an old aspect of one's self and the birth of a new and more capable self.

#### Stage 9: Reward (Seizing the Sword)

The Hero gains insights, receiving this as his **Reward** (the ninth stage). But the journey is not over yet.

---

### Phase Three: The Return

#### Stage 10: The Road Back

Now begins the third phase: **The Return**. In the tenth stage, **The Road Back**, the Hero must hold his reward and make his way back to the Ordinary World, but on the way he will be confronted with more enemies and dragons. However, the Hero knows that there's no way back and is motivated to keep going.

#### Stage 11: The Resurrection

In the eleventh stage, **The Resurrection**, the weary Hero must experience a second psychological death, experiencing a resurrection with the attributes of his ordinary self in addition to the new insights from the journey and characters he has met along the road of life. He moves from dependence to responsibility, from silence to finding his voice. The Hero has increased resilience and has learned how to regulate fear, sadness, and other emotions that arise when taking action.

He is now purified from the land of the dead and can return home.

#### Stage 12: Return with the Elixir

This leads to the twelfth and final stage: **Return with the Elixir**. The elixir is the final Reward earned on the Hero's Journey. It is something for the Hero to share with others, or something with the power to heal: wisdom, love, or simply the experience of surviving the Special World. The Hero comes back to his Ordinary World with a new self, having faced terrible dangers and possibly death, but now looks forward to the start of a new life.

---

## A Cyclical Journey

This is not just a one-time linear path, but in fact a lifelong cyclical process.

> "Over and over again, you are called to the realm of adventure, you are called to new horizons. Each time, there is the same problem: do I dare? And then if you do dare, the dangers are there, and the help also, and the fulfillment or the fiasco."

This awareness to see life as a Hero's Journey allows the chaos and challenges of life to have both some sequence and purpose. It gives us a beautiful framework for dealing with life's problems. An unwanted event can be viewed as a Call to Adventure, difficult life events as confronting one's dragon. When one completes these, one receives a reward, transforming into a new self, with an elixir to share the experience of one's Special World with others.

The Hero's Journey is:

> "The quest to find the inward thing that you basically are."

## Follow Your Bliss

One of Campbell's most frequently repeated phrases is to "Follow your bliss":

> "If you do follow your bliss you put yourself on a kind of track that has been there all the while, waiting for you, and the life you ought to be living is the one you are living. When you can see that, you begin to meet people who are in your field of bliss, and they open doors to you. I say, follow your bliss and don't be afraid, and doors will open where you didn't know they were going to be."

To follow one's bliss is not simply doing what one likes to do and certainly not what one is simply told. It is to search deeply within oneself and identify that pursuit or burning need which one is truly passionate about, giving oneself absolutely to it, and the rest will follow.

> "People say that what we're all seeking is a meaning for life. I don't think that's what we're really seeking. I think that what we're seeking is an experience of being alive, so that our life experiences on the purely physical plane will have resonances with our innermost being and reality, so that we actually feel the rapture of being alive."

## The Experience of Eternity

This feeling of rapture or bliss is associated with the Hero's Journey that we face on a daily basis in this life. He writes:

> "The experience of eternity right here and now is the function of life. Eternity isn't some later time. Eternity isn't even a long time. Eternity has nothing to do with time. Eternity is that dimension of the here and now that all thinking in temporal terms cuts off... the experience of eternity right here and now, in all things, whether thought of as good or as evil. Heaven is not the place to have the experience; here is the place to have the experience.
> 
> When you realize that eternity is right here now, that it is within your possibility to experience the eternity of your own truth and being, then you grasp the following:
> 
> **That which you are was never born and will never die.**"